var mCanvas=document.getElementById('mCanvas'),
	mctx=mCanvas.getContext('2d'),
	msize={w:1280,h:720},
	cursorN='pointer',
	moLs=[],
	renderQ=[],
	hovering=[],
	cursorP={x:0,y:0, grab: {x: 0, y:0} };
class cwin {
	constructor(zindex, width,height,title,onRender,posX,posY,bgColor){
		this.zindex=zindex;
		this.width=width;
		this.height=height;
		if(typeof title == 'undefined')this.title='Window'
		else this.title=title;
		
		if(typeof width == 'undefined')this.width=500
		else this.width=width;
		
		if(typeof height == 'undefined')this.height=500
		else this.height=height;
		
		if(typeof posX == 'undefined')this.posX = msize.w/2;
		else this.posX = posX
		
		if(typeof posY == 'undefined')this.posY = msize.h/2;
		else this.posY = posY
		
		if(typeof bgColor == 'undefined')this.bgColor = '#ccc'
		else this.bgColor = bgColor;
		
		this.eleID = moLs.length+1;
		
		moLs[this.eleID]={
			zindex: this.zindex,
			xpos: this.posX,
			ypos: this.posY,
			width: this.width,
			height: 25,
			hover: false,
			pressed: false,
			id: this.eleID,
			callback: (type,e)=>{
				var ele=moLs[this.eleID];
				if(!ele.pressed){ 
					moLs[this.eleID].ogxpos = ele.xpos
					moLs[this.eleID].ogypos = ele.ypos
				}
			}
		}
		
		renderQ[this.eleID]=(()=>{
			
			var ele=moLs[this.eleID];
			
			if(ele.pressed){ // when this is pressed, ignore hover statement
				var grabX = ele.ogxpos + cursorP.x - cursorP.grab.x,
					grabY = ele.ogypos + cursorP.y - cursorP.grab.y;
				// cursorN='move';
				moLs[this.eleID].xpos = grabX;
				moLs[this.eleID].ypos = grabY;
				
			} else if(ele.hover){
				// cursorN='link';
			}else{
				// cursorN='pointer';
			}
			
			mctx.fillStyle='#404040';
			mctx.fillRect(ele.xpos, ele.ypos, ele.width, ele.height);
			
			mctx.fillStyle='#fff';
			mctx.font = "18px Roboto";
			mctx.fillText(this.title, ele.xpos + 10 , ele.ypos +  ele.height/2 + 7 );
			
			
			// window contents
			
			mctx.fillStyle=this.bgColor;
			mctx.fillRect(ele.xpos, ele.ypos + ele.height, ele.width, 250);
			
			if(typeof onRender != 'undefined')onRender(ele);
		});
		
		// close button
		
		var closeEle_eleID = moLs.length+1,
			closeEle_xpos=msize.w/2,
			closeEle_ypos=msize.h/2,
			closeEle_width=17,
			closeEle_height=17;
		
		moLs[closeEle_eleID]={
			zindex: 10,
			xpos: closeEle_xpos,
			ypos: closeEle_ypos,
			width: closeEle_width,
			height: closeEle_height,
			hover: false,
			pressed: false
		};
		
		renderQ[closeEle_eleID]=(()=>{
			var ele=moLs[closeEle_eleID],
				windowBar=moLs[this.eleID];
			
			if(ele.pressed){
				mctx.fillStyle='#525252';
				renderQ.splice(this.eleID - 1 , 2);
			}else if(ele.hover){
				mctx.fillStyle='#bdbdbd';
			}else{
				mctx.fillStyle='#8a8a8a';
			}
			
			moLs[closeEle_eleID].xpos = windowBar.xpos + windowBar.width - 25;
			moLs[closeEle_eleID].ypos = windowBar.ypos + windowBar.height / 5;
			
			
			mctx.fillRect(windowBar.xpos + windowBar.width - 25,  windowBar.ypos + windowBar.height / 5, ele.width, ele.height);
			
		});
		
	}
}

mCanvas.width=msize.w;
mCanvas.height=msize.h;

mctx.fillStyle='#fff';
mctx.fillRect(0,0,msize.w,msize.h);

(()=>{ // taskbar
	var eleID = moLs.length+1,
		width=75,
		height=25,
		xpos=0,
		ypos=msize.h - height;
	
	var startOpen=false;
	
	moLs[eleID]={
		xpos: xpos,
		ypos: ypos,
		width: width,
		height: height,
		hover: false,
		pressed: false,
		zindex: 1000,
		callback: (type, e)=>{
			if(type == 'mouseDownLeft'){
				startOpen=!startOpen
			}
		}
	};
	
	// draw element
	
	
	
	renderQ.push(()=>{
		var ele=moLs[eleID];
		
		if(startOpen){
			mctx.fillStyle='#000';
			mctx.fillRect(ele.xpos, ele.ypos-400, 400, 400);
		}
		
		mctx.fillStyle='#2b2b2b';
		mctx.fillRect(0, msize.h - 25, msize.w, 25); // bottom panel before text
		
		if(ele.pressed){
			mctx.fillStyle='#25568f';
		}else if(ele.hover){
			mctx.fillStyle='#4297fb';
		}else{
			mctx.fillStyle='#1a385b';
			
		}
		
		mctx.fillRect(ele.xpos, ele.ypos, ele.width, ele.height);
		
		mctx.fillStyle='#fff';
		mctx.font = "20px Arial";
		mctx.fillText('start', ele.xpos + ele.width/5 , ele.ypos +  ele.height/2 + 7 );
		
	});
})();


// mouse stuff


mCanvas.addEventListener('mousemove', e=>{
	cursorP.x = e.layerX;
	cursorP.y = e.layerY;
	
	var moLsIndex=0;
	
	moLs.forEach((ee,ii)=>{
		var xRangeMin=ee.xpos,
			xRangeMax=ee.xpos+ee.width,
			yRangeMin=ee.ypos,
			yRangeMax=ee.ypos+ee.height,
			inXRange=(e.layerX >= xRangeMin && e.layerX <= xRangeMax),
			inYRange=(e.layerY >= yRangeMin && e.layerY <= yRangeMax);
		
		
		// console.log(ee);
		
		if(inXRange && inYRange){
			if(typeof ee.callback != 'undefined')ee.callback('mouseHover',e); // callback is called when cursor is inside range of element
			if(moLsIndex <= ee.zindex)moLsIndex = ii;
		}else{
			if(typeof ee.callback != 'undefined')ee.callback('mouseLeft', e);
			
			ee.hover = false;
		}
			
		
	});
	
	if(moLsIndex != false){
		moLs[moLsIndex].hover = true;
		moLs.forEach((e,i)=>{
			if(i != moLsIndex)e.hover = false;
		});
	}
});

mCanvas.addEventListener('mousedown', e=>{
	// console.log(e);
	
	// user is grabbing a thing so set it first
	cursorP.grab.x = e.layerX;
	cursorP.grab.y = e.layerY;
	
	var moLsIndex=0;
	
	moLs.forEach((ee,ii)=>{
		var xRangeMin=ee.xpos,
			xRangeMax=ee.xpos+ee.width,
			yRangeMin=ee.ypos,
			yRangeMax=ee.ypos+ee.height,
			inXRange=(e.layerX >= xRangeMin && e.layerX <= xRangeMax),
			inYRange=(e.layerY >= yRangeMin && e.layerY <= yRangeMax);
		
		
		// console.log(ee);
		
		if(inXRange && inYRange){
			if(e.button==2)type='mouseDownRight'
			else if(e.button==-0)type='mouseDownLeft';
			
			if(moLsIndex <= ee.zindex)moLsIndex = ii;
			
			if(typeof ee.callback != 'undefined')ee.callback(type,e); // callback is called when cursor is inside range of element and we are clicking
		}
			
		
	});
	
	if(moLsIndex != false){
		moLs[moLsIndex].pressed = true;
		moLs.forEach((e,i)=>{
			if(i != moLsIndex)e.pressed = false;
		});
	}
	
});

mCanvas.addEventListener('mouseup', e=>{
	// console.log(e);
	cursorP.grab.x = e.layerX;
	cursorP.grab.y = e.layerY;
	
	moLs.forEach((ee,ii)=>{
		var xRangeMin=ee.xpos,
			xRangeMax=ee.xpos+ee.width,
			yRangeMin=ee.ypos,
			yRangeMax=ee.ypos+ee.height,
			inXRange=(e.layerX >= xRangeMin && e.layerX <= xRangeMax),
			inYRange=(e.layerY >= yRangeMin && e.layerY <= yRangeMax),
			type='mouseDown';
		
		ee.pressed = false;
		
		if(inXRange && inYRange){ // only check if stuff is inside if there is callback 
			if(typeof ee.callback != 'undefined')ee.callback('mouseHover',e); 
		}
	});
});

setInterval(()=>{
	mctx.fillStyle='#2e7ac7';
	mctx.fillRect(0,0,msize.w,msize.h);
	mCanvas.style.cursor = 'url("./cursor/'+cursorN+'.cur"), none';

	renderQ.forEach((e,i)=>{
		e(); // run all render operations in order
	});
},1000/60);