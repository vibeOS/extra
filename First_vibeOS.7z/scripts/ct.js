// lines is an array of the last 10 or so lines displaying on the terminal
// lines = ['line', 'blah']

function runOnCmdLine(){
	return 'YE'; // the commandline will output all return data so it should show:
	// > runOnCmdLine()
	// YE
}
