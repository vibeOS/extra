var lines = [],
	termEle = {};

new cwin(moLs.length+1, 500 , 25, 'Terminal', (ele)=>{ // info panel
	if(lines.length > 10)lines.shift();
	
	termEle = ele;
	
	mctx.fillStyle='#fff';
	mctx.font = "16px Source Code Pro";
	
	lines.forEach((e,i)=>{
		mctx.fillText(e, ele.xpos + 10 , ele.ypos+50 + i*20 );
	});
	
}, msize.w/15, msize.h/6, '#000');

var inputBarID = moLs.length+1;

moLs[inputBarID]={
	zindex: 10,
	xpos: 0,
	ypos: 0,
	width: 470,
	height: 24,
	hover: false,
	pressed: false
};

var termStr='',
	prevTermStr='';

document.addEventListener('keydown', e=>{
	var ele=moLs[inputBarID];
	if(ele.hover){
		console.log(e);
		switch(e.keyCode){
			case 8: // backspace
				termStr=termStr.substr(0,termStr.length-1);
				break
			case 38: // up arrow
				termStr=prevTermStr;
				break
			case 16: // shift
			case 20: // acps lock
			case 36:
			case 144:
			case 93:
			case 17:
			case 27:
			case 9:
			case 91:
			case 18:
			case 46:
			case 35:
			case 34:
			case 45:
			case 33:
			case 40:
			case 39:
			case 37:
				break
			case 13: // enter key
				lines.push('> '+termStr);
				var output='';
				try {
					output=eval(termStr);
				}catch(err){
					output=err;
				}
				
				prevTermStr=termStr;
				termStr='';
				
				lines.push(output);
				
				break
			default:
				var keyyy=e.key
				termStr=termStr+keyyy;
				break
		}
	}
});

renderQ[inputBarID]=(()=>{
	var ele=moLs[inputBarID];
	
	/*if(ele.pressed){
		mctx.fillStyle='#525252';
	}else */
	if(ele.hover){
		mctx.fillStyle='#bdbdbd';
	}else{
		mctx.fillStyle='#8a8a8a';
	}
	
	moLs[inputBarID].xpos = termEle.xpos+15;
	moLs[inputBarID].ypos = termEle.ypos + 240;
	
	mctx.fillRect(ele.xpos, ele.ypos, ele.width, ele.height);
	
	mctx.fillStyle='#000';
	mctx.fillRect(ele.xpos+2, ele.ypos+2, ele.width-4, ele.height-4);
	
	mctx.fillStyle='#ccc';
	mctx.font = "14px Arial";
	mctx.fillText('> '+termStr, ele.xpos + 10 , ele.ypos +  ele.height/2 + 5 );
	
});

lines.push(Date.now()+' : Javascript terminal initated');